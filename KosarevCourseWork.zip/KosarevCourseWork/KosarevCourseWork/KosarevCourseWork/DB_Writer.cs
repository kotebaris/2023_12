﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KosarevCourseWork
{
    public class DB_Writer
    {
        public static string conStr = @"Data Source=(local);Initial Catalog=PolinomDB;Integrated Security=True;TrustServerCertificate=True";

        public static void WriteLog(double l, double r, double e, double s, string foo, string res)
        {
            string exp = "INSERT INTO UsageLog (L, R, E, S, Foo, Res) VALUES (@l,@r,@e,@s,@foo,@res)";

            SqlConnection connection = new SqlConnection(conStr);
            try
            {
                connection.Open();

                SqlCommand cmd = new SqlCommand(exp, connection);

                cmd.Parameters.Add("@l", SqlDbType.Float).Value = l;
                cmd.Parameters.Add("@r", SqlDbType.Float).Value = r;
                cmd.Parameters.Add("@e", SqlDbType.Float).Value = e;
                cmd.Parameters.Add("@s", SqlDbType.Float).Value = s;
                cmd.Parameters.Add("@foo", SqlDbType.NVarChar).Value = foo;
                cmd.Parameters.Add("@res", SqlDbType.NVarChar).Value = res;

                int number = cmd.ExecuteNonQuery();
                cmd.Dispose();
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        public static DataTable? GetLog()
        {
            try
            {
                var dataAdapter = new SqlDataAdapter("select * from UsageLogRu", conStr);
                
                var dataTable = new DataTable();

                dataAdapter.Fill(dataTable);

                return dataTable;

            }
            catch
            {
                return null;
            }

        }
    }
}
