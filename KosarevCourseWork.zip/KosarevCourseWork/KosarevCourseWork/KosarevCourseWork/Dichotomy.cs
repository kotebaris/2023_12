﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KosarevCourseWork
{
    public class Dichotomy
    {
        public double A {  get; set; }
        public double B { get; set; }
        public double E { get; set; }
        public double S { get; set; }
        public Func<double, double> F { get; set; }

        public (bool ok, string? msg) Check()
        {
            if(A >= B)
            {
                return (false, "Границы перепутаны");
            }
            if(E <= 0)
            {
                return (false, "Eps должен быть больше нуля");
            }
            if (S <= 0)
            {
                return (false, "Step должен быть больше нуля");
            }
            if (F == null)
            {
                return (false, "Не задана функция");
            }
            return (true, null);
        }

        public (string? error, double res) Find()
        {

            while (A < B)
            {
                if (!DoubleHasValue(F(A)))
                {
                    A += S;
                }
                else break;
            }
            while (A < B && F(A) * F(B) > 0)
            {
                A += S;
            }
            if (A >= B)
            {
                return ("no roots", double.MinValue);
            }
            
            double C = 0;
            while (B - A > E)
            {
                C = (A + B) / 2;
                if (F(B) * F(C) < 0)
                    A = C;
                else
                    B = C;
            }
            return (null, (A + B) / 2);
        }

        public static bool DoubleHasValue(double value)
        {
            return !Double.IsNaN(value) && !Double.IsInfinity(value);
        }
    }
}
