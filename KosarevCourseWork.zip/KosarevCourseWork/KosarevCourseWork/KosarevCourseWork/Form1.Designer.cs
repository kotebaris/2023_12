﻿namespace KosarevCourseWork
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            menuStrip1 = new MenuStrip();
            файлToolStripMenuItem = new ToolStripMenuItem();
            сохранитьГрафикКакИзображениеToolStripMenuItem = new ToolStripMenuItem();
            журналToolStripMenuItem = new ToolStripMenuItem();
            nudBorderL = new NumericUpDown();
            nudBorderR = new NumericUpDown();
            nudBorderE = new NumericUpDown();
            nudBorderS = new NumericUpDown();
            btFind = new Button();
            tbFoo = new TextBox();
            tbRes = new TextBox();
            labelFoo = new Label();
            labelRes = new Label();
            ((System.ComponentModel.ISupportInitialize)chart1).BeginInit();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudBorderL).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudBorderR).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudBorderE).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudBorderS).BeginInit();
            SuspendLayout();
            // 
            // chart1
            // 
            chartArea2.Name = "ChartArea1";
            chart1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            chart1.Legends.Add(legend2);
            chart1.Location = new Point(10, 110);
            chart1.Margin = new Padding(2);
            chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            chart1.Series.Add(series2);
            chart1.Size = new Size(621, 240);
            chart1.TabIndex = 0;
            chart1.Text = "chart1";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 58);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(33, 20);
            label1.TabIndex = 1;
            label1.Text = "лев";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(99, 58);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(43, 20);
            label2.TabIndex = 2;
            label2.Text = "прав";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(173, 58);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(32, 20);
            label3.TabIndex = 3;
            label3.Text = "eps";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(267, 58);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(35, 20);
            label4.TabIndex = 4;
            label4.Text = "шаг";
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { файлToolStripMenuItem, журналToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(5, 2, 0, 2);
            menuStrip1.Size = new Size(640, 28);
            menuStrip1.TabIndex = 5;
            menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            файлToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { сохранитьГрафикКакИзображениеToolStripMenuItem });
            файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            файлToolStripMenuItem.Size = new Size(59, 24);
            файлToolStripMenuItem.Text = "Файл";
            // 
            // сохранитьГрафикКакИзображениеToolStripMenuItem
            // 
            сохранитьГрафикКакИзображениеToolStripMenuItem.Name = "сохранитьГрафикКакИзображениеToolStripMenuItem";
            сохранитьГрафикКакИзображениеToolStripMenuItem.Size = new Size(345, 26);
            сохранитьГрафикКакИзображениеToolStripMenuItem.Text = "Сохранить график как изображение";
            сохранитьГрафикКакИзображениеToolStripMenuItem.Click += сохранитьГрафикКакИзображениеToolStripMenuItem_Click;
            // 
            // журналToolStripMenuItem
            // 
            журналToolStripMenuItem.Name = "журналToolStripMenuItem";
            журналToolStripMenuItem.Size = new Size(77, 24);
            журналToolStripMenuItem.Text = "Журнал";
            журналToolStripMenuItem.Click += журналToolStripMenuItem_Click;
            // 
            // nudBorderL
            // 
            nudBorderL.Location = new Point(18, 81);
            nudBorderL.Margin = new Padding(2);
            nudBorderL.Minimum = new decimal(new int[] { 100, 0, 0, int.MinValue });
            nudBorderL.Name = "nudBorderL";
            nudBorderL.Size = new Size(68, 27);
            nudBorderL.TabIndex = 6;
            nudBorderL.Value = new decimal(new int[] { 5, 0, 0, int.MinValue });
            // 
            // nudBorderR
            // 
            nudBorderR.Location = new Point(99, 81);
            nudBorderR.Margin = new Padding(2);
            nudBorderR.Minimum = new decimal(new int[] { 100, 0, 0, int.MinValue });
            nudBorderR.Name = "nudBorderR";
            nudBorderR.Size = new Size(69, 27);
            nudBorderR.TabIndex = 7;
            nudBorderR.Value = new decimal(new int[] { 10, 0, 0, 0 });
            // 
            // nudBorderE
            // 
            nudBorderE.DecimalPlaces = 6;
            nudBorderE.Increment = new decimal(new int[] { 1, 0, 0, 196608 });
            nudBorderE.Location = new Point(173, 81);
            nudBorderE.Margin = new Padding(2);
            nudBorderE.Name = "nudBorderE";
            nudBorderE.Size = new Size(90, 27);
            nudBorderE.TabIndex = 8;
            nudBorderE.Value = new decimal(new int[] { 1, 0, 0, 196608 });
            // 
            // nudBorderS
            // 
            nudBorderS.DecimalPlaces = 6;
            nudBorderS.Increment = new decimal(new int[] { 1, 0, 0, 131072 });
            nudBorderS.Location = new Point(267, 80);
            nudBorderS.Margin = new Padding(2);
            nudBorderS.Name = "nudBorderS";
            nudBorderS.Size = new Size(87, 27);
            nudBorderS.TabIndex = 9;
            nudBorderS.Value = new decimal(new int[] { 1, 0, 0, 131072 });
            // 
            // btFind
            // 
            btFind.Location = new Point(445, 30);
            btFind.Margin = new Padding(2);
            btFind.Name = "btFind";
            btFind.Size = new Size(176, 27);
            btFind.TabIndex = 10;
            btFind.Text = "Поиск";
            btFind.UseVisualStyleBackColor = true;
            btFind.Click += btFind_Click;
            // 
            // tbFoo
            // 
            tbFoo.Location = new Point(120, 28);
            tbFoo.Margin = new Padding(2);
            tbFoo.Name = "tbFoo";
            tbFoo.Size = new Size(121, 27);
            tbFoo.TabIndex = 11;
            tbFoo.Text = "x*x-1";
            tbFoo.TextChanged += tbFoo_TextChanged;
            // 
            // tbRes
            // 
            tbRes.Location = new Point(445, 80);
            tbRes.Margin = new Padding(2);
            tbRes.Name = "tbRes";
            tbRes.ReadOnly = true;
            tbRes.Size = new Size(177, 27);
            tbRes.TabIndex = 12;
            // 
            // labelFoo
            // 
            labelFoo.AutoSize = true;
            labelFoo.Location = new Point(18, 30);
            labelFoo.Margin = new Padding(2, 0, 2, 0);
            labelFoo.Name = "labelFoo";
            labelFoo.Size = new Size(101, 20);
            labelFoo.TabIndex = 13;
            labelFoo.Text = "Функция от Х";
            // 
            // labelRes
            // 
            labelRes.AutoSize = true;
            labelRes.Location = new Point(393, 81);
            labelRes.Margin = new Padding(2, 0, 2, 0);
            labelRes.Name = "labelRes";
            labelRes.Size = new Size(48, 20);
            labelRes.TabIndex = 14;
            labelRes.Text = "Oтвет";
            labelRes.Click += labelRes_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(640, 360);
            Controls.Add(labelRes);
            Controls.Add(labelFoo);
            Controls.Add(tbRes);
            Controls.Add(tbFoo);
            Controls.Add(btFind);
            Controls.Add(nudBorderS);
            Controls.Add(nudBorderE);
            Controls.Add(nudBorderR);
            Controls.Add(nudBorderL);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(chart1);
            Controls.Add(menuStrip1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MainMenuStrip = menuStrip1;
            Margin = new Padding(2);
            MaximizeBox = false;
            Name = "Form1";
            Text = "Главная форма";
            ((System.ComponentModel.ISupportInitialize)chart1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudBorderL).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudBorderR).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudBorderE).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudBorderS).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private MenuStrip menuStrip1;
        private NumericUpDown nudBorderL;
        private NumericUpDown nudBorderR;
        private NumericUpDown nudBorderE;
        private NumericUpDown nudBorderS;
        private Button btFind;
        private TextBox tbFoo;
        private TextBox tbRes;
        private Label labelFoo;
        private ToolStripMenuItem файлToolStripMenuItem;
        private ToolStripMenuItem сохранитьГрафикКакИзображениеToolStripMenuItem;
        private Label labelRes;
        private ToolStripMenuItem журналToolStripMenuItem;
    }
}
